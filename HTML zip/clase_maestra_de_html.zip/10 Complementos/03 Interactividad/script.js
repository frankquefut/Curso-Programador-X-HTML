function mostrarAlerta() {
    alert('Clic');
}